PocoLocale = {}
PocoLocale._defaultLocaleData = {}