-- PocoHud3 by zenyr@zenyr.com
if not TPocoBase or Pocohud_stop then return end
local disclaimer = [[
feel free to ask me through my mail: zenyr(at)zenyr.com. But please understand that I'm quite clumsy, cannot guarantee I'll reply what you want..
]]
-- Note: Due to quirky PreCommit hook, revision number would *appear to* be 1 revision before than "released" luac files.
local _ = UNDERSCORE
local REV = 467 -- git shortlog | wc -l
local TAG = '0.35' -- git describe --tags
local string_format = string.format
local inGame = Global.load_level
local inGameDeep
local me


PocoHud3Class = nil
Poco._req ('poco/Hud3_class.lua')
if not PocoHud3Class then return end

Poco._req ('poco/Hud3_Options.lua')
if not PocoHud3Class.Option then return end

local O = PocoHud3Class.Option:new()
PocoHud3Class.O = O
local K = PocoHud3Class.Kits:new()
PocoHud3Class.K = K
local L = PocoHud3Class.Localizer:new()
PocoHud3Class.L = L

PocoLocale = nil
Poco._req ('poco/loc/Hud3_LocaleIngame.lua')

--- Options ---
local YES,NO,yes,no = true,false,true,false
local ALTFONT= PocoHud3Class.ALTFONT
local FONT= PocoHud3Class.FONT
local FONTLARGE = PocoHud3Class.FONTLARGE
local Icon= PocoHud3Class.Icon
local PocoEvent= PocoHud3Class.PocoEvent

local now = function (type) return type and TimerManager:game():time() or managers.player:player_timer():time() end

--- Class Start ---
local TPocoHud3 = class(TPocoBase)
PocoHud3Class.TPocoHud3 = TPocoHud3
TPocoHud3.className = 'Hud'
TPocoHud3.classVersion = 3
--- Inherited ---
function TPocoHud3:onInit() -- ★설정
--	Poco:LoadOptions(self:name(1),O)
    O:load()
    L:load()

    PocoLocale = nil
    Poco._req ('poco/loc/Hud3_LocaleIngame.lua')

    self._ws = managers.gui_data:create_fullscreen_workspace()
    
    self.pnl = {
        dbg = self._ws:panel():panel({ name = 'dbg_sheet',  layer = 50000})
    }

    self.hooks = {}
    self.floats = {}
    self.sFloats = {}
    self:_hook()
    self:_updateBind()

    return true
end

--- Internal functions ---
function TPocoHud3:pidToPeer(pid)
    local session = managers.network:session()
    return session and session:peer(pid)
end

function TPocoHud3:say(line,sync)
    if line then
        local sound = _.g('managers.player:player_unit():sound()')
        if not sound then return end
        return sound:say(line,true,sync)
    end
end

function TPocoHud3:Menu(dismiss, skipAnim)
    local C = PocoHud3Class
    local _drawUpgrades = C._drawUpgrades

    local r,err = pcall(function()
        local menu = self.menuGui
        if menu then -- Remove
            self:_updateBind()
            if not self._stringFocused or (now()-self._stringFocused > 0.1) then
                self.menuGui = nil
                self._noRose = nil
                self._guiFading = true
                if self.onMenuDismiss then
                    local cbk = self.onMenuDismiss
                    self.onMenuDismiss = nil
                    cbk()
                end
                if not self:say('g92',true) then
                    managers.menu_component:post_event('menu_exit')
                end

                if skipAnim then
                    menu:destroy()
                    self._guiFading = nil
                else
                    menu:fadeOut(function()
                        self._guiFading = nil
                        menu:destroy()
                    end)
                end
            end
        elseif not dismiss and not self._guiFading and not managers.system_menu:is_active() then -- Show
            if not self:say('a01x_any',true) then
                managers.menu_component:post_event('menu_enter')
            end
            local gui = C.PocoMenu:new(self._ws)
            self.menuGui = gui
            self._noRose = true
            gui:fadeIn()
            --- Install tabs Begin --- ===================================

            tab = gui:add(L('_tab_tools'))
            do
                local oTabs = C.PocoTabs:new(self._ws,{name = 'tools',x = 10, y = 10, w = 970, th = 30, fontSize = 18, h = tab.pnl:height()-20, pTab = tab})
                local oTab = oTabs:add(L('_tab_jukebox'))
                PocoHud3Class._drawJukebox(oTab)
            end
            local tab = gui:add(L('_tab_options'))
            C._drawOptions(tab)
        end
    end)
    if not r then _('MenuCallErr',err) end
end


function TPocoHud3:SimpleFloat(data) -- {key,x,y,time,text,size,val,anim,offset,icon,rect}
    local key = data.key
    if key and self.sFloats[key] then
        self.sFloats[key]:hide()
        self.sFloats[key] = nil
    end
    local pnl = self.pnl.dbg:panel{x = data.x, y = data.y, w=500, h=100}
    if key then
        self.sFloats[key] = pnl
    end
    pnl:rect{color=cl.Black,layer=-1,alpha=data.rect or 0.9}
    local offset = data.offset or {0,0}
    local anim = data.anim
    local __, lbl = _.l({pnl=pnl,x=5,y=5, font=FONT, color=cl.White, font_size=data.size},data.text,true)
    if data.icon then
        local icon,rect = unpack(data.icon)
        local bmp = pnl:bitmap{
            name = 'icon',
            texture = icon,
            texture_rect = rect,
            x = 5, y = 5
        }
        bmp:set_center_y(5 + data.size/2)

        lbl:set_x(bmp:width()+10)
    end
    pnl:set_size(lbl:right()+5,lbl:bottom()+5)
    pnl:stop()
    local t = now()
    pnl:animate(function(p)
        while alive(p) and p:visible() do
            local dt = now() - t
            local r = dt / data.time
            if r > 1 then break end
            if anim == 1 then
                r = math.pow(r,0.5)
                local rr = math.min(r,1-r)
                p:set_alpha(math.pow(rr,0.4))
            end
            local dx,dy = offset[1] * r, offset[2] * r
            p:set_position(math.floor(data.x + dx),math.floor(data.y + dy))
            coroutine.yield()
        end
        if alive(p) then
            if p:visible() then
                self.sFloats[key] = nil
            end
            p:parent():remove(p)
        end
    end)
end

function TPocoHud3:_updateBind()
    Poco:UnBind(self)

    Poco:Bind(self,O:get('root','optionsMenuKey'),function()
        self:Menu(false,false)
    end)
    local keys = K:keys()
    
end

function TPocoHud3:_peer(something)
    local t = type(something)
    if t == 'userdata' then
        return alive(something) and something:network() and something:network():peer()
    end
    if t == 'number' then
        return self:pidToPeer(something)
    end
    if t == 'string' then
        return self:_peer(managers.criminals:character_peer_id_by_name( something ))
    end
end
function TPocoHud3:_pid(something)
    local peer = self:_peer(something)
    return peer and peer:id() or 0
end

function TPocoHud3:ImportFloats()
    local show_minions = floatO.showTargetsConvert
    for _, data in pairs(self._floats_to_load or {}) do
        if data.category == 0 and data.tag and data.tag.minion and show_minions then
            self:MinionFloat(data.unit, 0, {minion = data.tag.minion})
        elseif data.category == 1 then
            self:Float(data.unit, 1)
        end
    end
    self._floats_to_load = nil
end

function TPocoHud3:Refresh()
    if managers.groupai and managers.groupai:state() and self._game_started then
        local ai_criminals = managers.groupai:state():all_AI_criminals()
        for _, data in pairs(ai_criminals or {}) do
            local unit = data.unit
            if unit and alive(unit) and unit:base() and unit:base().Poco_Refresh then
                unit:base():Poco_Refresh()
            end
        end
    end
end

function TPocoHud3:_hook()
    local Run = function(key, ...)
        if self.hooks[key] then
            return self.hooks[key][2](...)
        end
    end
    local hook = function(Obj, key, newFunc)
        local realKey = key:gsub('%*%a*','')
        if Obj and not self.hooks[key] then
            self.hooks[key] = {Obj,Obj[realKey]}
            Obj[realKey] = function(...)
                if (me and me.dead) or not me then
                    return Run(key,...)
                else
                    return newFunc(...)
                end
            end
        else
            _('!!Hook Failed:'..key)
        end
    end
    
    function TPocoHud3:onDestroy(gameEnd)
        self:Menu(true, true) -- Force dismiss menu
        if alive(self._ws) then
            managers.gui_data:destroy_workspace(self._ws)
        end
    end
    
    if inGame then
        -- Kill PocoHud on restart
        hook(GamePlayCentralManager, 'restart_the_game', function(self, ...)
            Pocohud_stop = true
            me:onDestroy(gameEnd)
            me.Toggle()
            Run('restart_the_game', self, ...)
            PocoHud3 = nil
        end)

        --PlayerStandard
        hook(PlayerStandard, '_get_input', function(self, ...)
            return me.menuGui and {} or Run('_get_input', self, ...)
        end)
        if O:get('root','pocoRoseHalt') then
            hook(PlayerStandard, '_determine_move_direction', function(self, ...)
                Run('_determine_move_direction', self, ...)
                if me.menuGui then
                    self._move_dir = nil
                    self._normal_move_dir = nil
                end
            end)
        end

    else -- if outGame
        if managers.player then
            managers.player._coroutine_mgr:clear()
        end
    end -- End of if inGame

    -- Mouse hook plugin

    hook(MenuRenderer, 'mouse_moved', function(...)
        --local self, o, x, y = unpack{...}
        if me.menuGui then
            return true
        else
            return Run('mouse_moved', ...)
        end
    end)
    hook(MenuInput, 'mouse_moved*', function(...)
        local self, o, x, y = unpack{...}
        if me.menuGui then
            if not inGame then
                return me.menuGui:mouse_moved(true, o, x, y)
            else
                return true
            end
        else
            return Run('mouse_moved*', ...)
        end
    end)
    hook(MenuManager, 'toggle_menu_state', function(...)
        if me.menuGui then
            me:Menu(true) -- dismiss Menu when actual game-menu is called
            if managers.menu:active_menu() then
                managers.menu:active_menu().renderer:disable_input(0.2)
            end

        else
            return Run('toggle_menu_state', ...)
        end
    end)
    hook(MenuInput, 'update**', function(...)
        if Poco._kbd:pressed(28) and alt() then
            managers.viewport:set_fullscreen(not RenderSettings.fullscreen)
        else
            return Run('update**', ...)
        end
    end)
    if inGame then
        hook(FPCameraPlayerBase, '_update_rot', function(...)
            if me.menuGui then
                return false
            else
                return Run('_update_rot', ...)
            end
        end)
    end

    -- Music hook
    local function MusicChange(s)
        if O:get("root","showMusicTitle") then
            me:SimpleFloat{key='showMusicTitle',x=10,y=10,time=5,anim=1,offset={200,0},
                text={{_.s(O:get("root","showMusicTitlePrefix")),cl.White:with_alpha(0.6)},{s,cl.Tan}},
                size=24, icon = {tweak_data.hud_icons:get_icon_data('jukebox_playing_icon')}
            }
        end
    end
    local ms = _.g('Global.music_manager.source')
    if ms then
        hook(getmetatable(ms), 'set_switch', function(self, type, val, ...)
            if type == 'music_randomizer' and val then
                local s = managers.localization:text("menu_jukebox_" .. val)
                MusicChange(s)
            end
            return Run('set_switch', self, type, val, ...)
        end)
    end
    --MusicManager:jukebox_menu_track(name)
    hook(MusicManager, 'jukebox_menu_track', function(...)
        local result = Run('jukebox_menu_track', ...)
        if result then
            local s = managers.localization:text("menu_jukebox_screen_" .. result)
            MusicChange(s)
        end
        return result
    end)
    --function LevelsTweakData:get_music_event(stage)
    hook(LevelsTweakData, 'get_music_event', function(...)
        local result = Run('get_music_event', ...)
        if result and O('root','shuffleMusic') then
            local self,stage = unpack{...}
            if stage == 'control' then
                if self._poco_can_shuffle then
                    _.g('managers.music:check_music_switch()')
                else
                    self._poco_can_shuffle = 1
                end
            end
        end
        return result
    end)
end

--- Class end ---
PocoHud3 = PocoHud3
TPocoHud3.Toggle = function()
    me = Poco:AddOn(TPocoHud3)
    DC = Poco.DelayedCallsFix
    if me and not me.dead then
        PocoHud3 = me
    else
        PocoHud3 = true
    end
    PocoHud3Class.loadVar(O,me,L)
    if me then
		me:ImportFloats()
        me:Refresh()
	end
end
if Poco and not Poco.dead then
    TPocoHud3.Toggle()
else
    managers.menu_component:post_event('zoom_out')
end